<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReasonFor extends Model
{
    protected $fillable = [
        'name','status'
    ];
}
