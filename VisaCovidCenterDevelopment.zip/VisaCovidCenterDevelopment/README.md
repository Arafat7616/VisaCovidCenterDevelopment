## Follow belows steps to install this project

-   Download the project or clone it `git clone git@github.com:MRRaihan/VisaCovidCenterDevelopment`
-   **Run:** `cp .env.example .env` then configure your database
-   **Run:** `npm install && npm run dev`
-   **Run:** `composer install`
-   **Run:** `php artisan key:generate`
-   **Run:** `php artisan migrate:fresh --seed`

## Now you are ready to go :).

## Credintials to login

-   **Password:** Password is `12345` for all portal
-   **Super admin:** `01732955937` (apurbo vai)
-   **Administrator:** `01749969029` (raihan vai)
-   **Volunteer:** `01303613363` (shohan)
-   **Receptionist:** `01777382007` (shohan)
-   **Pathologist:** `01732379393` (shonat vai)
-   **Immigration Officer :** `01871006624` (raihan vai)
-   **Govt Portal :** `01635431430` (joti vai)
