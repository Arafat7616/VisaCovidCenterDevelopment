<!-- Start Footerbar -->
<footer>
    <div class="row fixed-bottom shadow-sm mt-5">
        <div class="col-12">
            <div class="footer text-center">
                <p class="py-4">&copy; Visa Covid {{ date('Y') }} </p>
            </div>
        </div>
    </div>
</footer>
<!-- End Footerbar -->
