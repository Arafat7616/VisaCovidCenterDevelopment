@extends('Administrator.layouts.master')

@push('title')
    Dashboard
@endpush

@push('css')

@endpush

@section('content')
    
    <div>
        This is dashboard page
    </div>
@endsection

@push('script')

@endpush
